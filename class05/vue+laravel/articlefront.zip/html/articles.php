<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Articles - API Call</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Articles Dashboard</a>
            <div class="navbar-nav ms-auto">
                <button class="btn btn-outline-light" id="logoutBtn">Logout</button>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <h2>Articles</h2>
                
                <!-- Alert for messages -->
                <div id="alertContainer"></div>
                
                <!-- Loading spinner -->
                <div id="loadingSpinner" class="text-center my-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading articles...</p>
                </div>
                
                <!-- Articles container -->
                <div id="articlesContainer" class="d-none">
                    <div class="row" id="articlesList">
                        <!-- Articles will be populated here -->
                    </div>
                </div>
                
                <!-- No articles message -->
                <div id="noArticlesMessage" class="text-center my-5 d-none">
                    <div class="alert alert-info">
                        <h4>No Articles Found</h4>
                        <p>There are no articles available at the moment.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        const API_BASE_URL = 'http://localhost/ROUND64/laravel/API/articleservice/public/api';
        
        // Helper function to get stored token
        function getApiToken() {
            return localStorage.getItem('api_token');
        }
        
        // Helper function to make authenticated API calls
        async function makeAuthenticatedRequest(url, options = {}) {
            const token = getApiToken();
            
            if (!token) {
                throw new Error('No authentication token found');
            }
            
            const defaultHeaders = {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };
            
            const mergedOptions = {
                ...options,
                headers: {
                    ...defaultHeaders,
                    ...(options.headers || {})
                }
            };
            
            return fetch(url, mergedOptions);
        }
        
        // Function to show alerts
        function showAlert(message, type) {
            const alertContainer = document.getElementById('alertContainer');
            alertContainer.innerHTML = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
        }
        
        // Function to format date
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
        
        // Function to create article card
        function createArticleCard(article) {
            return `
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">${article.title || 'Untitled'}</h5>
                            <p class="card-text">${article.content ? article.content.substring(0, 100) + '...' : 'No content available'}</p>
                    </div>
                </div>
            `;
        }
        
        // Function to load articles
        async function loadArticles() {
            const loadingSpinner = document.getElementById('loadingSpinner');
            const articlesContainer = document.getElementById('articlesContainer');
            const noArticlesMessage = document.getElementById('noArticlesMessage');
            const articlesList = document.getElementById('articlesList');
            
            try {
                // Check if user is authenticated
                const token = getApiToken();
                if (!token) {
                    showAlert('You are not logged in. Redirecting to login...', 'warning');
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 2000);
                    return;
                }
                
                // Show loading
                loadingSpinner.classList.remove('d-none');
                articlesContainer.classList.add('d-none');
                noArticlesMessage.classList.add('d-none');
                
                // Make API call
                const response = await makeAuthenticatedRequest(`${API_BASE_URL}/articles`);
                
                if (response.status === 401) {
                    // Token expired or invalid
                    localStorage.removeItem('api_token');
                    localStorage.removeItem('user_data');
                    showAlert('Session expired. Please login again.', 'warning');
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 2000);
                    return;
                }
                
                const data = await response.json();
                
                if (response.ok) {
                    // Hide loading
                    loadingSpinner.classList.add('d-none');
                    
                    // Check if articles exist
                    const articles = data.data || data.articles || data;
                    
                    if (articles && articles.length > 0) {
                        // Populate articles
                        articlesList.innerHTML = articles.map(article => createArticleCard(article)).join('');
                        articlesContainer.classList.remove('d-none');
                        showAlert(`Found ${articles.length} articles`, 'success');
                    } else {
                        // No articles found
                        noArticlesMessage.classList.remove('d-none');
                    }
                } else {
                    // API error
                    loadingSpinner.classList.add('d-none');
                    const errorMessage = data.message || data.error || 'Failed to load articles';
                    showAlert(errorMessage, 'danger');
                }
                
            } catch (error) {
                console.error('Error loading articles:', error);
                loadingSpinner.classList.add('d-none');
                
                if (error.message === 'No authentication token found') {
                    showAlert('You are not logged in. Redirecting to login...', 'warning');
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 2000);
                } else {
                    showAlert('Network error. Please try again.', 'danger');
                }
            }
        }
        
        // Logout function
        function logout() {
            localStorage.removeItem('api_token');
            localStorage.removeItem('user_data');
            showAlert('Logged out successfully. Redirecting...', 'success');
            setTimeout(() => {
                window.location.href = 'login.php';
            }, 1500);
        }
        
        // Event listeners
        document.getElementById('logoutBtn').addEventListener('click', logout);
        
        // Load articles when page loads
        window.addEventListener('load', loadArticles);
    </script>
</body>
</html>