<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - API Call</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="card mt-5 shadow">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Login</h2>
                        
                        <!-- Alert for messages -->
                        <div id="alertContainer"></div>
                        
                        <form id="loginForm">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary" id="loginBtn">
                                    <span id="loginBtnText">Login</span>
                                    <span id="loginSpinner" class="spinner-border spinner-border-sm d-none" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
       // const API_BASE_URL = 'http://192.168.54.81/ROUND64/laravel/larablog/public/api';
        const API_BASE_URL = 'http://localhost/ROUND64/laravel/API/articleservice/public/api';
        
        document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const loginBtn = document.getElementById('loginBtn');
            const loginBtnText = document.getElementById('loginBtnText');
            const loginSpinner = document.getElementById('loginSpinner');
            const alertContainer = document.getElementById('alertContainer');
            
            // Get form data
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Show loading state
            loginBtn.disabled = true;
            loginBtnText.textContent = 'Logging in...';
            loginSpinner.classList.remove('d-none');
            alertContainer.innerHTML = '';
            
            try {
                const response = await fetch(`${API_BASE_URL}/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                });
                
                const data = await response.json();
                
                if (response.ok && data.token) {
                    console.log('Login successful:', data);
                    // Save token to localStorage for future API calls
                    localStorage.setItem('api_token', data.token);
                    localStorage.setItem('user_data', JSON.stringify(data.user || {}));
                    
                    showAlert('Login successful! Redirecting...', 'success');
                    
                    // Redirect after 2 seconds
                    setTimeout(() => {
                        window.location.href = 'articles.php';
                    }, 2000);
                    
                } else {
                    // Handle error response
                    const errorMessage = data.message || data.error || 'Login failed. Please check your credentials.';
                    showAlert(errorMessage, 'danger');
                }
                
            } catch (error) {
                console.error('Login error:', error);
                showAlert('Network error. Please try again.', 'danger');
            } finally {
                // Reset button state
                loginBtn.disabled = false;
                loginBtnText.textContent = 'Login';
                loginSpinner.classList.add('d-none');
            }
        });
        
        function showAlert(message, type) {
            const alertContainer = document.getElementById('alertContainer');
            alertContainer.innerHTML = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
        }
        
        // Helper function to get stored token for future API calls
        function getApiToken() {
            return localStorage.getItem('api_token');
        }
        
        // Helper function to make authenticated API calls
        async function makeAuthenticatedRequest(url, options = {}) {
            const token = getApiToken();
            
            if (!token) {
                throw new Error('No authentication token found');
            }
            
            const defaultHeaders = {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };
            
            const mergedOptions = {
                ...options,
                headers: {
                    ...defaultHeaders,
                    ...(options.headers || {})
                }
            };
            
            return fetch(url, mergedOptions);
        }
        
        // Check if user is already logged in
        window.addEventListener('load', function() {
            const token = getApiToken();
            if (token) {
                // Optional: Verify token is still valid
                // You might want to redirect to dashboard if already logged in
                console.log('User already has a token');
            }
        });
    </script>
</body>
</html>