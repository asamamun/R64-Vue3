<template>
  <div class="container-fluid min-vh-100 bg-light">
    <!-- Header -->
    <header class="bg-white shadow-sm sticky-top">
      <div class="container py-3">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h1 class="h4 mb-0 fw-bold text-primary">
              <i class="bi bi-journals me-2"></i>
              Article Manager
            </h1>
            <p class="mb-0 text-muted small">Manage your articles efficiently</p>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-outline-secondary rounded-pill" @click="handleRefresh">
              <i class="bi bi-arrow-repeat me-1"></i>
              Refresh
            </button>
            <button class="btn btn-danger rounded-pill" @click="handleLogout">
              <i class="bi bi-box-arrow-right me-1"></i>
              Logout
            </button>
          </div>
        </div>
      </div>
    </header>

    <div class="container py-4">
      <!-- Action Bar -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="h5 mb-0 fw-bold">Your Articles</h2>
          <p class="mb-0 text-muted small">Manage all your published articles</p>
        </div>
        <router-link to="/articles/create" class="btn btn-primary rounded-pill shadow-sm">
          <i class="bi bi-plus-lg me-1"></i>
          Create Article
        </router-link>
      </div>
      
      <!-- Alert for messages -->
      <div v-if="articlesStore.error" class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        {{ articlesStore.error }}
        <button type="button" class="btn-close" @click="articlesStore.error = null"></button>
      </div>
      
      <!-- Loading spinner -->
      <div v-if="articlesStore.loading" class="text-center my-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
        <p class="mt-2 text-muted">Loading your articles...</p>
      </div>
      
      <!-- Articles container -->
      <div v-else>
        <div v-if="articlesStore.articles.length === 0" class="text-center my-5 py-5">
          <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-4 mx-auto" style="width: 100px; height: 100px;">
            <i class="bi bi-journal-text text-muted" style="font-size: 3rem;"></i>
          </div>
          <h3 class="h5 fw-bold text-dark">No Articles Found</h3>
          <p class="text-muted mb-4">You haven't created any articles yet.</p>
          <router-link to="/articles/create" class="btn btn-primary rounded-pill">
            <i class="bi bi-plus-lg me-1"></i>
            Create Your First Article
          </router-link>
        </div>
        
        <div v-else class="row g-4" id="articlesList">
          <div 
            v-for="article in articlesStore.articles" 
            :key="article.id" 
            class="col-lg-4 col-md-6"
          >
            <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title fw-bold text-dark">{{ article.title || 'Untitled' }}</h5>
                <p class="card-text text-muted flex-grow-1">
                  {{ truncatedContent(article.content) }}
                </p>
                <div class="d-flex justify-content-between align-items-center mt-3">
                  <small class="text-muted">
                    <i class="bi bi-calendar me-1"></i>
                    {{ formatDate(article.created_at) }}
                  </small>
                  <div class="btn-group" role="group">
                    <router-link 
                      :to="`/articles/edit/${article.id}`" 
                      class="btn btn-outline-primary btn-sm rounded-pill"
                    >
                      <i class="bi bi-pencil me-1"></i>
                      Edit
                    </router-link>
                    <button 
                      @click="deleteArticle(article.id)" 
                      class="btn btn-outline-danger btn-sm rounded-pill"
                      :disabled="deletingArticleId === article.id"
                    >
                      <span v-if="deletingArticleId === article.id">
                        <span class="spinner-border spinner-border-sm" role="status"></span>
                      </span>
                      <span v-else>
                        <i class="bi bi-trash me-1"></i>
                        Delete
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useArticlesStore } from '@/stores/articles'

const router = useRouter()
const authStore = useAuthStore()
const articlesStore = useArticlesStore()

const deletingArticleId = ref(null)

// Truncate content helper
const truncatedContent = (content) => {
  if (!content) return 'No content available'
  return content.length > 100 
    ? content.substring(0, 100) + '...' 
    : content
}

// Format date function
const formatDate = (dateString) => {
  if (!dateString) return 'Unknown date'
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

// Load articles when component mounts
onMounted(async () => {
  await articlesStore.fetchArticles()
})

// Handle refresh
const handleRefresh = async () => {
  await articlesStore.fetchArticles()
}

// Handle logout
const handleLogout = () => {
  authStore.logout()
  router.push('/login')
}

// Delete article
const deleteArticle = async (id) => {
  if (!confirm('Are you sure you want to delete this article? This action cannot be undone.')) {
    return
  }
  
  deletingArticleId.value = id
  try {
    const result = await articlesStore.deleteArticle(id)
    if (result.success) {
      // Article deleted successfully
      // The store automatically updates the articles list
    } else {
      // Handle error
      console.error('Failed to delete article:', result.error)
    }
  } finally {
    deletingArticleId.value = null
  }
}
</script>

<style scoped>
.card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  border: 1px solid rgba(0, 0, 0, 0.05);
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
}

.btn-primary {
  background: linear-gradient(135deg, #0d6efd, #0b5ed7);
  border: none;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #0b5ed7, #0a58ca);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3) !important;
}

.btn-danger {
  background: linear-gradient(135deg, #dc3545, #bb2d3b);
  border: none;
}

.btn-danger:hover {
  background: linear-gradient(135deg, #bb2d3b, #a72534);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3) !important;
}

header {
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}
</style>