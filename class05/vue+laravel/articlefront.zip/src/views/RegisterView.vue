<template>
  <div class="container-fluid min-vh-100 d-flex align-items-center bg-light">
    <div class="row w-100 justify-content-center">
      <div class="col-lg-5 col-md-7 col-sm-9">
        <div class="card shadow-lg border-0 rounded-3">
          <div class="card-body p-5">
            <div class="text-center mb-4">
              <div class="bg-success rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                <i class="bi bi-person-plus text-white" style="font-size: 2rem;"></i>
              </div>
              <h2 class="h4 fw-bold text-dark">Create Account</h2>
              <p class="text-muted">Sign up for a new account</p>
            </div>
            
            <!-- Alert for messages -->
            <div v-if="errorMessage" class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
              <i class="bi bi-exclamation-triangle-fill me-2"></i>
              {{ errorMessage }}
              <button type="button" class="btn-close" @click="errorMessage = ''"></button>
            </div>
            
            <div v-if="successMessage" class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
              <i class="bi bi-check-circle-fill me-2"></i>
              {{ successMessage }}
              <button type="button" class="btn-close" @click="successMessage = ''"></button>
            </div>
            
            <form @submit.prevent="handleRegister">
              <div class="mb-3">
                <label for="name" class="form-label fw-medium">Full Name</label>
                <div class="input-group">
                  <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-person text-muted"></i>
                  </span>
                  <input 
                    type="text" 
                    class="form-control border-start-0" 
                    id="name" 
                    v-model="form.name" 
                    placeholder="Enter your full name"
                    required
                    :disabled="loading"
                  >
                </div>
              </div>
              
              <div class="mb-3">
                <label for="email" class="form-label fw-medium">Email Address</label>
                <div class="input-group">
                  <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-envelope text-muted"></i>
                  </span>
                  <input 
                    type="email" 
                    class="form-control border-start-0" 
                    id="email" 
                    v-model="form.email" 
                    placeholder="name@example.com"
                    required
                    :disabled="loading"
                  >
                </div>
              </div>
              
              <div class="mb-3">
                <label for="password" class="form-label fw-medium">Password</label>
                <div class="input-group">
                  <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-lock text-muted"></i>
                  </span>
                  <input 
                    type="password" 
                    class="form-control border-start-0" 
                    id="password" 
                    v-model="form.password" 
                    placeholder="Create a password"
                    required
                    :disabled="loading"
                  >
                </div>
              </div>
              
              <div class="mb-4">
                <label for="password_confirmation" class="form-label fw-medium">Confirm Password</label>
                <div class="input-group">
                  <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-lock-fill text-muted"></i>
                  </span>
                  <input 
                    type="password" 
                    class="form-control border-start-0" 
                    id="password_confirmation" 
                    v-model="form.password_confirmation" 
                    placeholder="Confirm your password"
                    required
                    :disabled="loading"
                  >
                </div>
              </div>
              
              <div class="d-grid mb-3">
                <button 
                  type="submit" 
                  class="btn btn-success btn-lg rounded-3 shadow-sm" 
                  :disabled="loading"
                >
                  <span v-if="!loading">
                    <i class="bi bi-person-check me-2"></i>
                    Create Account
                  </span>
                  <span v-else>
                    <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                    Creating Account...
                  </span>
                </button>
              </div>
              
              <div class="text-center">
                <p class="mb-0 text-muted">
                  Already have an account? 
                  <router-link to="/login" class="text-decoration-none fw-medium">
                    <i class="bi bi-box-arrow-in-right me-1"></i>
                    Sign in here
                  </router-link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const form = reactive({
  name: '',
  email: '',
  password: '',
  password_confirmation: ''
})

const loading = ref(false)
const errorMessage = ref('')
const successMessage = ref('')

const handleRegister = async () => {
  loading.value = true
  errorMessage.value = ''
  successMessage.value = ''
  
  // Basic password confirmation check
  if (form.password !== form.password_confirmation) {
    errorMessage.value = 'Passwords do not match'
    loading.value = false
    return
  }
  
  try {
    const result = await authStore.register({
      name: form.name,
      email: form.email,
      password: form.password,
      password_confirmation: form.password_confirmation
    })
    
    if (result.success) {
      successMessage.value = 'Registration successful! You can now login.'
      // Reset form
      form.name = ''
      form.email = ''
      form.password = ''
      form.password_confirmation = ''
      // Redirect to login after a short delay
      setTimeout(() => {
        router.push('/login')
      }, 2000)
    } else {
      errorMessage.value = result.error
    }
  } catch (error) {
    errorMessage.value = 'An unexpected error occurred. Please try again.'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
}

.input-group-text {
  border-radius: 0.375rem 0 0 0.375rem !important;
}

.form-control {
  border-radius: 0 0.375rem 0.375rem 0 !important;
}

.btn-success {
  background: linear-gradient(135deg, #198754, #157347);
  border: none;
}

.btn-success:hover {
  background: linear-gradient(135deg, #157347, #146c43);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(25, 135, 84, 0.3) !important;
}
</style>