<template>
  <div class="container-fluid min-vh-100 d-flex align-items-center bg-light">
    <div class="row w-100 justify-content-center">
      <div class="col-lg-4 col-md-6 col-sm-8">
        <div class="card shadow-lg border-0 rounded-3">
          <div class="card-body p-5">
            <div class="text-center mb-4">
              <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                <i class="bi bi-person-circle text-white" style="font-size: 2rem;"></i>
              </div>
              <h2 class="h4 fw-bold text-dark">Welcome Back</h2>
              <p class="text-muted">Sign in to your account</p>
            </div>
            
            <!-- Alert for messages -->
            <div v-if="errorMessage" class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
              <i class="bi bi-exclamation-triangle-fill me-2"></i>
              {{ errorMessage }}
              <button type="button" class="btn-close" @click="errorMessage = ''"></button>
            </div>
            
            <div v-if="successMessage" class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
              <i class="bi bi-check-circle-fill me-2"></i>
              {{ successMessage }}
              <button type="button" class="btn-close" @click="successMessage = ''"></button>
            </div>
            
            <form @submit.prevent="handleLogin">
              <div class="mb-3">
                <label for="email" class="form-label fw-medium">Email Address</label>
                <div class="input-group">
                  <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-envelope text-muted"></i>
                  </span>
                  <input 
                    type="email" 
                    class="form-control border-start-0" 
                    id="email" 
                    v-model="form.email" 
                    placeholder="name@example.com"
                    required
                    :disabled="loading"
                  >
                </div>
              </div>
              
              <div class="mb-4">
                <label for="password" class="form-label fw-medium">Password</label>
                <div class="input-group">
                  <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-lock text-muted"></i>
                  </span>
                  <input 
                    type="password" 
                    class="form-control border-start-0" 
                    id="password" 
                    v-model="form.password" 
                    placeholder="Enter your password"
                    required
                    :disabled="loading"
                  >
                </div>
              </div>
              
              <div class="d-grid mb-3">
                <button 
                  type="submit" 
                  class="btn btn-primary btn-lg rounded-3 shadow-sm" 
                  :disabled="loading"
                >
                  <span v-if="!loading">
                    <i class="bi bi-box-arrow-in-right me-2"></i>
                    Sign In
                  </span>
                  <span v-else>
                    <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                    Signing In...
                  </span>
                </button>
              </div>
              
              <div class="text-center">
                <p class="mb-0 text-muted">
                  Don't have an account? 
                  <router-link to="/register" class="text-decoration-none fw-medium">
                    <i class="bi bi-person-plus me-1"></i>
                    Register here
                  </router-link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const form = reactive({
  email: '',
  password: ''
})

const loading = ref(false)
const errorMessage = ref('')
const successMessage = ref('')

const handleLogin = async () => {
  loading.value = true
  errorMessage.value = ''
  successMessage.value = ''
  
  try {
    const result = await authStore.login({
      email: form.email,
      password: form.password
    })
    
    if (result.success) {
      successMessage.value = 'Login successful! Redirecting...'
      // Redirect after a short delay
      setTimeout(() => {
        router.push('/articles')
      }, 1500)
    } else {
      errorMessage.value = result.error
    }
  } catch (error) {
    errorMessage.value = 'An unexpected error occurred. Please try again.'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
}

.input-group-text {
  border-radius: 0.375rem 0 0 0.375rem !important;
}

.form-control {
  border-radius: 0 0.375rem 0.375rem 0 !important;
}

.btn-primary {
  background: linear-gradient(135deg, #0d6efd, #0b5ed7);
  border: none;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #0b5ed7, #0a58ca);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3) !important;
}
</style>