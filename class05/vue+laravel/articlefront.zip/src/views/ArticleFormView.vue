<template>
  <div class="container-fluid min-vh-100 bg-light">
    <!-- Header -->
    <header class="bg-white shadow-sm sticky-top">
      <div class="container py-3">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h1 class="h4 mb-0 fw-bold text-primary">
              <i class="bi bi-journal-text me-2"></i>
              {{ isEditing ? 'Edit Article' : 'Create Article' }}
            </h1>
            <p class="mb-0 text-muted small">
              {{ isEditing ? 'Update your existing article' : 'Create a new article' }}
            </p>
          </div>
          <router-link to="/articles" class="btn btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i>
            Back to Articles
          </router-link>
        </div>
      </div>
    </header>

    <div class="container py-4">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="card border-0 shadow-sm rounded-3">
            <div class="card-body p-4 p-md-5">
              <div class="text-center mb-4">
                <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                  <i class="bi bi-journal-text text-white" style="font-size: 2rem;"></i>
                </div>
                <h2 class="h4 fw-bold text-dark">
                  {{ isEditing ? 'Edit Your Article' : 'Create New Article' }}
                </h2>
                <p class="text-muted">
                  {{ isEditing ? 'Update your article details below' : 'Share your thoughts with the world' }}
                </p>
              </div>
              
              <!-- Alert for messages -->
              <div v-if="errorMessage" class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                {{ errorMessage }}
                <button type="button" class="btn-close" @click="errorMessage = ''"></button>
              </div>
              
              <form @submit.prevent="handleSubmit">
                <div class="mb-4">
                  <label for="title" class="form-label fw-medium">Article Title</label>
                  <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                      <i class="bi bi-type-h1 text-muted"></i>
                    </span>
                    <input 
                      type="text" 
                      class="form-control border-start-0" 
                      id="title" 
                      v-model="form.title" 
                      placeholder="Enter a compelling title"
                      required
                      :disabled="articlesStore.loading"
                    >
                  </div>
                </div>
                
                <div class="mb-4">
                  <label for="content" class="form-label fw-medium">Article Content</label>
                  <div class="input-group">
                    <span class="input-group-text bg-white border-end-0 align-items-start pt-3">
                      <i class="bi bi-file-text text-muted"></i>
                    </span>
                    <textarea 
                      class="form-control border-start-0" 
                      id="content" 
                      rows="10" 
                      v-model="form.content" 
                      placeholder="Write your article content here..."
                      required
                      :disabled="articlesStore.loading"
                    ></textarea>
                  </div>
                </div>
                
                <div class="d-flex flex-column flex-md-row justify-content-between gap-3">
                  <router-link to="/articles" class="btn btn-outline-secondary rounded-pill flex-fill">
                    <i class="bi bi-x-lg me-1"></i>
                    Cancel
                  </router-link>
                  <button 
                    type="submit" 
                    class="btn btn-primary rounded-pill flex-fill shadow-sm" 
                    :disabled="articlesStore.loading"
                  >
                    <span v-if="!articlesStore.loading">
                      <i class="bi bi-save me-1"></i>
                      {{ isEditing ? 'Update Article' : 'Publish Article' }}
                    </span>
                    <span v-else>
                      <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                      {{ isEditing ? 'Updating...' : 'Publishing...' }}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useArticlesStore } from '@/stores/articles'

const router = useRouter()
const route = useRoute()
const articlesStore = useArticlesStore()

const isEditing = ref(false)
const articleId = ref(null)
const errorMessage = ref('')

const form = reactive({
  title: '',
  content: ''
})

// Check if we're editing an existing article
onMounted(async () => {
  if (route.params.id) {
    isEditing.value = true
    articleId.value = route.params.id
    
    // Load the article data
    const result = await articlesStore.fetchArticle(articleId.value)
    if (result.success) {
      form.title = result.data.title || ''
      form.content = result.data.content || ''
    } else {
      errorMessage.value = result.error
    }
  }
})

const handleSubmit = async () => {
  errorMessage.value = ''
  
  try {
    let result
    if (isEditing.value) {
      // Update existing article
      result = await articlesStore.updateArticle(articleId.value, {
        title: form.title,
        content: form.content
      })
    } else {
      // Create new article
      result = await articlesStore.createArticle({
        title: form.title,
        content: form.content
      })
    }
    
    if (result.success) {
      // Redirect to articles list after successful operation
      router.push('/articles')
    } else {
      errorMessage.value = result.error
    }
  } catch (error) {
    errorMessage.value = 'An unexpected error occurred. Please try again.'
  }
}
</script>

<style scoped>
.card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  border: 1px solid rgba(0, 0, 0, 0.05);
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
}

.input-group-text {
  border-radius: 0.375rem 0 0 0.375rem !important;
}

.form-control {
  border-radius: 0 0.375rem 0.375rem 0 !important;
}

.btn-primary {
  background: linear-gradient(135deg, #0d6efd, #0b5ed7);
  border: none;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #0b5ed7, #0a58ca);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3) !important;
}

header {
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}
</style>