import { defineStore } from 'pinia'
import api from '@/services/api'

export const useArticlesStore = defineStore('articles', {
    state: () => ({
        articles: [],
        currentArticle: null,
        loading: false,
        error: null
    }),

    getters: {
        allArticles: (state) => state.articles,
        getArticleById: (state) => (id) => state.articles.find(article => article.id == id)
    },

    actions: {
        async fetchArticles() {
            this.loading = true
            this.error = null

            try {
                const response = await api.get('/articles')
                this.articles = response.data.data || response.data.articles || response.data
                return { success: true, data: this.articles }
            } catch (error) {
                this.error = error.response?.data?.message || 'Failed to fetch articles'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        async fetchArticle(id) {
            this.loading = true
            this.error = null

            try {
                const response = await api.get(`/articles/${id}`)
                this.currentArticle = response.data.data || response.data
                return { success: true, data: this.currentArticle }
            } catch (error) {
                this.error = error.response?.data?.message || 'Failed to fetch article'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        async createArticle(articleData) {
            this.loading = true
            this.error = null

            try {
                const response = await api.post('/articles', articleData)
                const newArticle = response.data.data || response.data

                // Add to articles list
                this.articles.push(newArticle)

                return { success: true, data: newArticle }
            } catch (error) {
                this.error = error.response?.data?.message || 'Failed to create article'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        async updateArticle(id, articleData) {
            this.loading = true
            this.error = null

            try {
                const response = await api.put(`/articles/${id}`, articleData)
                const updatedArticle = response.data.data || response.data

                // Update in articles list
                const index = this.articles.findIndex(article => article.id == id)
                if (index !== -1) {
                    this.articles[index] = updatedArticle
                }

                // Update current article if it's the one being updated
                if (this.currentArticle && this.currentArticle.id == id) {
                    this.currentArticle = updatedArticle
                }

                return { success: true, data: updatedArticle }
            } catch (error) {
                this.error = error.response?.data?.message || 'Failed to update article'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        },

        async deleteArticle(id) {
            this.loading = true
            this.error = null

            try {
                await api.delete(`/articles/${id}`)

                // Remove from articles list
                this.articles = this.articles.filter(article => article.id != id)

                // Clear current article if it's the one being deleted
                if (this.currentArticle && this.currentArticle.id == id) {
                    this.currentArticle = null
                }

                return { success: true }
            } catch (error) {
                this.error = error.response?.data?.message || 'Failed to delete article'
                return { success: false, error: this.error }
            } finally {
                this.loading = false
            }
        }
    }
})