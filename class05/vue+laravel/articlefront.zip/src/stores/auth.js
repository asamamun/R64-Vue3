import { defineStore } from 'pinia'
import api from '@/services/api'

export const useAuthStore = defineStore('auth', {
    state: () => ({
        user: null,
        token: localStorage.getItem('api_token') || null,
        isLoggedIn: false
    }),

    getters: {
        isAuthenticated: (state) => !!state.token,
        currentUser: (state) => state.user
    },

    actions: {
        async login(credentials) {
            try {
                const response = await api.post('/login', credentials)
                const { token, user } = response.data

                this.token = token
                this.user = user
                this.isLoggedIn = true

                // Save token to localStorage
                localStorage.setItem('api_token', token)

                // Set default authorization header for future requests
                api.defaults.headers.common['Authorization'] = `Bearer ${token}`

                return { success: true, data: response.data }
            } catch (error) {
                // Remove token if login fails
                this.logout()
                return { success: false, error: error.response?.data?.message || 'Login failed' }
            }
        },

        async register(userData) {
            try {
                const response = await api.post('/register', userData)
                return { success: true, data: response.data }
            } catch (error) {
                return { success: false, error: error.response?.data?.message || 'Registration failed' }
            }
        },

        logout() {
            this.user = null
            this.token = null
            this.isLoggedIn = false

            // Remove token from localStorage
            localStorage.removeItem('api_token')

            // Remove default authorization header
            delete api.defaults.headers.common['Authorization']
        },

        async checkAuth() {
            if (!this.token) {
                return false
            }

            try {
                // Set default authorization header
                api.defaults.headers.common['Authorization'] = `Bearer ${this.token}`

                // Optionally verify token with backend
                const response = await api.get('/user')
                this.user = response.data
                this.isLoggedIn = true
                return true
            } catch (error) {
                this.logout()
                return false
            }
        }
    }
})