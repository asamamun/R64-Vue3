import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

// Import views
const LoginView = () => import('@/views/LoginView.vue')
const RegisterView = () => import('@/views/RegisterView.vue')
const ArticlesView = () => import('@/views/ArticlesView.vue')
const ArticleFormView = () => import('@/views/ArticleFormView.vue')

// Define routes
const routes = [
  {
    path: '/',
    redirect: '/articles'
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginView
  },
  {
    path: '/register',
    name: 'Register',
    component: RegisterView
  },
  {
    path: '/articles',
    name: 'Articles',
    component: ArticlesView,
    meta: { requiresAuth: true }
  },
  {
    path: '/articles/create',
    name: 'CreateArticle',
    component: ArticleFormView,
    meta: { requiresAuth: true }
  },
  {
    path: '/articles/edit/:id',
    name: 'EditArticle',
    component: ArticleFormView,
    meta: { requiresAuth: true },
    props: true
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

// Navigation guard
router.beforeEach(async (to, from, next) => {
  const authStore = useAuthStore()

  // Check if route requires authentication
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // Check if user is logged in
    if (!authStore.isAuthenticated) {
      // Try to restore auth state
      await authStore.checkAuth()

      // If still not authenticated, redirect to login
      if (!authStore.isAuthenticated) {
        next('/login')
        return
      }
    }
  }

  // If user is logged in and trying to access login/register, redirect to articles
  if (to.path === '/login' || to.path === '/register') {
    if (authStore.isAuthenticated) {
      next('/articles')
      return
    }
  }

  next()
})

export default router