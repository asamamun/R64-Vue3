import axios from 'axios'

// Create axios instance
const api = axios.create({
    baseURL: 'http://localhost/ROUND64/laravel/API/articleservice/public/api',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    withCredentials: false // Set to false to match your CORS configuration
})

// Add a request interceptor to include Bearer token
api.interceptors.request.use(
    (config) => {
        // Get API token from localStorage (if available)
        const apiToken = localStorage.getItem('api_token')
        if (apiToken) {
            config.headers['Authorization'] = `Bearer ${apiToken}`
        }

        return config
    },
    (error) => {
        return Promise.reject(error)
    }
)

// Add a response interceptor to handle token expiration
api.interceptors.response.use(
    (response) => {
        return response
    },
    (error) => {
        if (error.response?.status === 401) {
            // Token expired or invalid
            localStorage.removeItem('api_token')
            // Optionally redirect to login page
            // window.location.href = '/login'
        }
        return Promise.reject(error)
    }
)

export default api