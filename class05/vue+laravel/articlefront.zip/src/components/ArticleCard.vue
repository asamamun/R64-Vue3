<template>
  <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden">
    <div class="card-body d-flex flex-column">
      <h5 class="card-title fw-bold text-dark">{{ article.title || 'Untitled' }}</h5>
      <p class="card-text text-muted flex-grow-1">{{ truncatedContent }}</p>
      <div class="d-flex justify-content-between align-items-center mt-3">
        <small class="text-muted">
          <i class="bi bi-calendar me-1"></i>
          {{ formattedDate }}
        </small>
        <div>
          <slot name="actions"></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  article: {
    type: Object,
    required: true
  }
})

// Computed properties
const truncatedContent = computed(() => {
  if (!props.article.content) return 'No content available'
  return props.article.content.length > 100 
    ? props.article.content.substring(0, 100) + '...' 
    : props.article.content
})

const formattedDate = computed(() => {
  if (!props.article.created_at) return 'Unknown date'
  const date = new Date(props.article.created_at)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
})
</script>

<style scoped>
.card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  border: 1px solid rgba(0, 0, 0, 0.05);
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
}
</style>